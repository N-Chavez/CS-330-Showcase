#include <application.h>
#include <iostream>
#include <shapes.h>
#include <vector>
#include <Sphere.h>
#include <glm/gtc/matrix_transform.hpp>
#include <stb_image.h>
#include <texture.h>
#include <types.h>
#include <light.h>

Application::Application(std::string WindowTitle, int width, int height) : _applicationName{ WindowTitle }, _width{ width }, _height{ height },
_camera{ width, height, {0.0f, 0.0f, 3.0f}, true },
_cameraLookSpeed{ 0.06f, 0.06f } {}

void Application::Run() {
	// Open the window
	if (!openWindow()) {
		return;
	}

	setupInputs();

	_running = true;

	// Setup scene
	setupScene();

	// Run application
	while (_running) {
		float currTime = glfwGetTime();

		if (_lastFrameTime == -1.0f) {
			_lastFrameTime = currTime;
		}

		auto deltaTime = currTime - _lastFrameTime;
		_lastFrameTime = currTime;
		if (glfwWindowShouldClose(_window)) {
			_running = false;
			continue;
		}

		// Update
		update(deltaTime);

		//Draw
		draw();

	}

	glfwTerminate();
}

bool Application::openWindow() {
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);

	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	_window = glfwCreateWindow(800, 600, "LearnOpenGL", nullptr, nullptr);

	if (!_window) {
		std::cerr << "Failed to create GLFW window!" << std::endl;
		glfwTerminate();
	}

	glfwMakeContextCurrent(_window);
	glfwSetWindowUserPointer(_window, (void*)this);

	glfwSetFramebufferSizeCallback(_window, [](GLFWwindow* window, int width, int height) {
		std::cout << "Window has resized!" << std::endl;
		glViewport(0, 0, width, height);

		auto app = reinterpret_cast<Application*>(glfwGetWindowUserPointer(window));
		app->_width = width;
		app->_height = height;

		app->_camera.SetSize(width, height);
	});

	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
		std::cerr << "Failed to intialize GLAD" << std::endl;
		glfwTerminate();
		return false;
	}

	glEnable(GL_DEPTH_TEST);

	/*glFrontFace(GL_CCW);
	glCullFace(GL_BACK);
	glEnable(GL_CULL_FACE);*/

	return true;
}

void Application::setupInputs() {
	glfwSetKeyCallback(_window, [](GLFWwindow* window, int key, int scancode, int action, int mods) {
		auto* app = reinterpret_cast<Application*>(glfwGetWindowUserPointer(window));

		switch (key) {
			case GLFW_KEY_ESCAPE: {
				if (action == GLFW_PRESS) {
					app->_running = false;
				}
				break;
			}
			case GLFW_KEY_F11: {
				if (action == GLFW_PRESS) {
					app->_camera.SetIsPerspective(!app->_camera.IsPerspective());
				}
			}
			default: {}
		}
	});

	glfwSetCursorPosCallback(_window, [](GLFWwindow* window, double xpos, double ypos) {
		auto* app = reinterpret_cast<Application*>(glfwGetWindowUserPointer(window));

	//	app->mousePosCallback(xpos, ypos);

	});

	glfwSetScrollCallback(_window, [](GLFWwindow* window, double xOffset, double yOffset) {
		auto* app = reinterpret_cast<Application*>(glfwGetWindowUserPointer(window));
		app->_camera.IncrementZoom(yOffset * 2);
	});

	glfwSetMouseButtonCallback(_window, [](GLFWwindow* window, int button, int action, int mods) {
		switch (button) {
		case GLFW_MOUSE_BUTTON_LEFT: {
			if (action == GLFW_PRESS) {
				std::cout << "Left mouse button pressed" << std::endl;
			}
			else {

			}
			break;
		}
		case GLFW_MOUSE_BUTTON_MIDDLE: {
			if (action == GLFW_PRESS) {
				std::cout << "Middle mouse button pressed" << std::endl;
			}
			else {

			}
			break;
		}
		case GLFW_MOUSE_BUTTON_RIGHT: {
			if (action == GLFW_PRESS) {
				std::cout << "Right mouse button pressed" << std::endl;

			}
			else {

			}
			break;
		}
		default:
			std::cout << "Unhandled mouse button event" << std::endl;
		}
	});
}

void Application::setupScene() {
	auto& cube1 = _meshes.emplace_back(Shapes::cubeVertices, Shapes::cubeElements);
	cube1.Transform = glm::translate(cube1.Transform, glm::vec3(-1.0f, 0.5f, -0.5f));
	cube1.Transform = glm::scale(cube1.Transform, glm::vec3(0.6f, 0.6f, 0.6f));

	auto& cube2 = _meshes.emplace_back(Shapes::cubeVertices, Shapes::cubeElements);
	cube2.Transform = glm::translate(cube2.Transform, glm::vec3(-1.0f, -0.25f, -0.5f));
	cube2.Transform = glm::scale(cube2.Transform, glm::vec3(0.6f, 0.6f, 0.6f));

	auto& cube3 = _meshes.emplace_back(Shapes::cubeVertices, Shapes::cubeElements);
	cube3.Transform = glm::translate(cube3.Transform, glm::vec3(-1.0f, -1.0f, -0.5f));
	cube3.Transform = glm::scale(cube3.Transform, glm::vec3(0.6f, 0.6f, 0.6f));

	auto& cylinder1 = _meshes.emplace_back(Shapes::cylinderVertices, Shapes::cylinderElements);
	cylinder1.Transform = glm::translate(cylinder1.Transform, glm::vec3(-1.0f, -1.13f, -0.5f));
	cylinder1.Transform = glm::scale(cylinder1.Transform, glm::vec3(0.25f, 0.75f, 0.25f));

	auto& cylinder2 = _meshes.emplace_back(Shapes::cylinderVertices, Shapes::cylinderElements);
	cylinder2.Transform = glm::translate(cylinder2.Transform, glm::vec3(-1.0f, -0.5f, -0.5f));
	cylinder2.Transform = glm::scale(cylinder2.Transform, glm::vec3(0.25f, 0.75f, 0.25f));

	auto& cylinder3 = _meshes.emplace_back(Shapes::cylinderVertices, Shapes::cylinderElements);
	cylinder3.Transform = glm::translate(cylinder3.Transform, glm::vec3(-1.0f, 0.25f, -0.5f));
	cylinder3.Transform = glm::scale(cylinder3.Transform, glm::vec3(0.25f, 0.75f, 0.25f));

	auto& pyramid1 = _meshes.emplace_back(Shapes::pyramidVertices, Shapes::pyramidElements);
	pyramid1.Transform = glm::translate(pyramid1.Transform, glm::vec3(1.0f, 0.35f, -0.5f));
	pyramid1.Transform = glm::scale(pyramid1.Transform, glm::vec3(0.25f, 0.25f, 0.25f));

	auto& pyramid2 = _meshes.emplace_back(Shapes::pyramidVertices, Shapes::pyramidElements);
	pyramid2.Transform = glm::translate(pyramid2.Transform, glm::vec3(1.0f, 0.1f, -0.5f));
	pyramid2.Transform = glm::scale(pyramid2.Transform, glm::vec3(0.5f, 0.5f, 0.5f));

	auto& pyramid3 = _meshes.emplace_back(Shapes::pyramidVertices, Shapes::pyramidElements);
	pyramid3.Transform = glm::translate(pyramid3.Transform, glm::vec3(1.0f, -0.25f, -0.5f));
	pyramid3.Transform = glm::scale(pyramid3.Transform, glm::vec3(0.75f, 0.75f, 0.75f));

	auto& pyramid4 = _meshes.emplace_back(Shapes::pyramidVertices, Shapes::pyramidElements);
	pyramid4.Transform = glm::translate(pyramid4.Transform, glm::vec3(1.0f, -0.65f, -0.5f)); 

	auto& cylinder4 = _meshes.emplace_back(Shapes::cylinderVertices, Shapes::cylinderElements);
	cylinder4.Transform = glm::translate(cylinder4.Transform, glm::vec3(1.0f, -1.0f, -0.5f));
	cylinder4.Transform = glm::scale(cylinder4.Transform, glm::vec3(0.25f, 1.0f, 0.25f));

	auto& plane1 = _meshes.emplace_back(Shapes::planeVertices, Shapes::planeElements);
	plane1.Transform = glm::translate(plane1.Transform, glm::vec3(0.0f, 0.5f, 0.0f));
	plane1.Transform = glm::scale(plane1.Transform, glm::vec3(2.0f, 2.0f, 2.0f));

	auto& plane2 = _meshes.emplace_back(Shapes::planeVertices, Shapes::planeElements);
	plane2.Transform = glm::translate(plane2.Transform, glm::vec3(0.0f, 0.501f, 0.0f));
	plane2.Transform = glm::scale(plane2.Transform, glm::vec3(0.5f, 2.0f, 2.0f));

	auto& cube4 = _meshes.emplace_back(Shapes::cubeVertices, Shapes::cubeElements);
	cube4.Transform = glm::translate(cube4.Transform, glm::vec3(-1.0f, -1.2f, 1.0f));
	cube4.Transform = glm::scale(cube4.Transform, glm::vec3(0.5f, 0.5f, 0.5f));

	auto& cube5 = _meshes.emplace_back(Shapes::cubeVertices, Shapes::cubeElements);
	cube5.Transform = glm::translate(cube5.Transform, glm::vec3(-1.0f, -1.2f, 1.25f));
	cube5.Transform = glm::scale(cube5.Transform, glm::vec3(0.5f, 0.5f, 0.5f));

	auto& cube6 = _meshes.emplace_back(Shapes::cubeVertices, Shapes::cubeElements);
	cube6.Transform = glm::translate(cube6.Transform, glm::vec3(1.0f, -1.2f, 1.0f));
	cube6.Transform = glm::scale(cube6.Transform, glm::vec3(0.5f, 0.5f, 0.5f));

	auto& cube7 = _meshes.emplace_back(Shapes::cubeVertices, Shapes::cubeElements);
	cube7.Transform = glm::translate(cube7.Transform, glm::vec3(1.0f, -1.2f, 1.25f));
	cube7.Transform = glm::scale(cube7.Transform, glm::vec3(0.5f, 0.5f, 0.5f));

	Path shaderPath = std::filesystem::current_path() / "assets" / "shaders";
	//_shader = Shader(shaderPath / "basic_unlit_color.vert", shaderPath / "basic_unlit_color.frag");
	//_shader = Shader(shaderPath / "basic_lit.vert", shaderPath / "basic_lit.frag");
	_shader = Shader(shaderPath / "basic_shader.vert", shaderPath / "basic_shader.frag");

	auto texturePath = std::filesystem::current_path() / "assets" / "textures";
	_textures.emplace_back(texturePath / "leaves.jpg");
	_textures.emplace_back(texturePath / "leavesc1.jpg");
	_textures.emplace_back(texturePath / "leavesc2.jpg");
	_textures.emplace_back(texturePath / "birch.jpg");
	_textures.emplace_back(texturePath / "birchc1.jpg");
	_textures.emplace_back(texturePath / "birchc2.jpg");
	_textures.emplace_back(texturePath / "pines2.jpeg");
	_textures.emplace_back(texturePath / "pines2c1.jpeg");
	_textures.emplace_back(texturePath / "pines2c2.jpeg");
	_textures.emplace_back(texturePath / "pines2c3.jpeg");
	_textures.emplace_back(texturePath / "pinebark.jpg");
	_textures.emplace_back(texturePath / "grass.jpg");
	_textures.emplace_back(texturePath / "dirt.jpg");
	_textures.emplace_back(texturePath / "shrub.jpg");
	_textures.emplace_back(texturePath / "shrubc1.jpg");
	_textures.emplace_back(texturePath / "shrubc2.jpg");
	_textures.emplace_back(texturePath / "shrubc3.jpg");

}

bool Application::update(float deltaTime) {
	glfwPollEvents();
	handleInput(deltaTime);

	return false;
}

bool Application::draw() {
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glm::mat4 view = _camera.GetViewMatrix();
	glm::mat4 projection = _camera.GetProjectionMatrix();

	/*SceneParameters sceneParams{
		.ProjectionMatrix = projection,
		.ViewMatrix = view,
		.CameraPosition = _camera.GetPosition(),
		.DirLight = {
			.Direction = glm::normalize(glm::vec3{-0.2f, -0.5f, 1.0f}),
			.AmbientColor = {0.1f, 0.2f, 0.05f},
			.DiffuseColor = {0.9f, 1.0f, 0.7f},
			.SpecularColor = {0.9f, 1.0f, 0.7f}
		}
	};*/

	
	_shader.Bind();
	_shader.SetMat4("projection", projection);
	_shader.SetMat4("view", view);
	/*_shader.SetInt("tex0", 0);
	_shader.SetInt("tex1", 1);
	_shader.SetInt("tex2", 2);
	_shader.SetInt("tex3", 3);
	_shader.SetInt("tex4", 4);*/

	for (auto i = 0; i < _meshes.size(); i++) {
		auto& mesh = _meshes[i];
		auto& texture = _textures[i];

		glActiveTexture(GL_TEXTURE0 + i);
		texture.Bind();

		_shader.SetInt("tex0", i);
		_shader.SetInt("tex1", i + 1);
		_shader.SetInt("tex2", i + 2);
		_shader.SetInt("tex3", i + 3);
		_shader.SetInt("tex4", i + 4);

		_shader.SetMat4("model", mesh.Transform);
		mesh.Draw();

	}

	
	/*for (int i = 0; i < _textures.size(); i++) {
		glActiveTexture(GL_TEXTURE0 + i);
		_textures[i].Bind();
	}

	for (auto& mesh : _meshes) {
		//mesh.Transform = glm::rotate(mesh.Transform, glm::radians(0.25f), glm::vec3(0, 1, 0));
		//mesh.Transform = glm::rotate(mesh.Transform, glm::radians(0.25f), glm::vec3(1, 0, 0));
		_shader.SetMat4("model", mesh.Transform);
		mesh.Draw();
	}*/

	glfwSwapBuffers(_window);

	return false;
}

void Application::handleInput(float deltaTime) {
	auto moveAmount = _moveSpeed * deltaTime;

	if (glfwGetKey(_window, GLFW_KEY_W)) {
		_camera.MoveCamera(Camera::MoveDirection::Forward, moveAmount);
	}
	if (glfwGetKey(_window, GLFW_KEY_S)) {
		_camera.MoveCamera(Camera::MoveDirection::Backward, moveAmount);
	}
	if (glfwGetKey(_window, GLFW_KEY_A)) {
		_camera.MoveCamera(Camera::MoveDirection::Right, moveAmount);
	}
	if (glfwGetKey(_window, GLFW_KEY_D)) {
		_camera.MoveCamera(Camera::MoveDirection::Left, moveAmount);
	}
	if (glfwGetKey(_window, GLFW_KEY_Q)) {
		_camera.MoveCamera(Camera::MoveDirection::Up, moveAmount);
	}
	if (glfwGetKey(_window, GLFW_KEY_E)) {
		_camera.MoveCamera(Camera::MoveDirection::Down, moveAmount);
	}

	double xpos, ypos;
	glfwGetCursorPos(_window, &xpos, &ypos);
	mousePosCallback(xpos, ypos);
}

void Application::mousePosCallback(double xpos, double ypos) {
	if (!_firstMouse) {
		_lastMousePosition.x = static_cast<float>(xpos);
		_lastMousePosition.y = static_cast<float>(ypos);
		_firstMouse = true;
	}
	glm::vec2 moveAmount{
		xpos - _lastMousePosition.x,
		_lastMousePosition.y - ypos
	};

	_lastMousePosition.x = static_cast<float>(xpos);
	_lastMousePosition.y = static_cast<float>(ypos);

	_camera.RotateBy(moveAmount.x * _cameraLookSpeed.x, moveAmount.y * _cameraLookSpeed.y);
}

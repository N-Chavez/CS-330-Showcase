#include <application.h>
#include <light.h>
#include <shapes.h>



Light::Light() {
	createShader();
	createMesh();
}

void Light::Init() {

}

void Light::Update(float deltaTime) {
	auto cos = std::cos(totalTime);
	auto sin = std::sin(totalTime);

	// Transform = glm::translate(Transform, glm::vec3(cos / 10, 0, sin / 10));
	
	totalTime += deltaTime;
}

void Light::Draw(SceneParameters& sceneParams) {
	/*for (auto mesh : _meshes) {
		auto &shader = _basicUnlitShader;
		shader->Bind();
		shader->SetMat4("projection", sceneParams.ProjectionMatrix);
		shader->SetMat4("view", sceneParams.ViewMatrix);
		shader->SetMat4("model", mesh.Transform);

		mesh.Draw();
	}*/
}

void Light::createShader() {
	_basicUnlitShader = std::make_shared<Shader>(Path("basic_unlit_color.vert"), Path("basic_unlit_color.frag"));
}

void Light::createMesh() {
	auto cube = std::make_shared<Mesh>(Shapes::cubeVertices, Shapes::cubeElements, glm::vec3(1.0f, 1.0f, 1.0f));
	//_meshes.emplace_back(cube, _basicUnlitShader);
}

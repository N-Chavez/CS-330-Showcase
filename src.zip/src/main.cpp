#include <iostream>
#include <application.h>
#include <glm/glm.hpp>

int main(int argc, char** argv) {

	Application app{ "CS330-ShowcaseApp", 800, 600 };

	app.Run();

	return 0;
}
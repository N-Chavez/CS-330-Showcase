#pragma once
#define _USE_MATH_DEFINES
#include <glm/glm.hpp>
#include <vector>
#include <math.h>
#include <types.h>
#include <cmath>
#include <utility>
#include <numbers>

struct Shapes {
	static inline void UpdateNormals(Vertex& p1, Vertex& p2, Vertex& p3) {
		glm::vec3 U = p2.Position - p1.Position;
		glm::vec3 V = p3.Position - p1.Position;

		auto normal = glm::cross(U, V);

		p1.Normal = normal;
		p2.Normal = normal;
		p3.Normal = normal;
	}

	static inline std::vector<Vertex> cubeVertices{
		// Front Face
		{
			.Position = {-0.5, 0.5f, 0.5f},
			.Color = {1.0f, 0.5f, 0.5f},
			.Uv = {0.0f, 1.0f}
		},
		{
			.Position = {-0.5, -0.5f, 0.5f},
			.Color = {1.0f, 0.5f, 0.5f},
			.Uv = {0.0f, 0.0f}
		},		
		{
			.Position = {0.5, -0.5f, 0.5f},
			.Color = {1.0f, 0.5f, 0.5f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {0.5, 0.5f, 0.5f},
			.Color = {1.0f, 0.5f, 0.5f},
			.Uv = {1.0f, 1.0f}
		},
		// Right Face
		{
			.Position = {0.5, 0.5f, 0.5f},
			.Color = {0.5f, 0.5f, 0.5f},
			.Uv = {0.0f, 1.0f}
		},
		{
			.Position = {0.5, -0.5f, 0.5f},
			.Color = {0.5f, 0.5f, 0.5f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {0.5, -0.5f, -0.5f},
			.Color = {0.5f, 0.5f, 0.5f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {0.5, 0.5f, -0.5f},
			.Color = {0.5f, 0.5f, 0.5f},
			.Uv = {1.0f, 1.0f}
		},
		// Back Face
		{
			.Position = {0.5, 0.5f, -0.5f},
			.Color = {1.0f, 1.0f, 0.5f},
			.Uv = {0.0f, 1.0f}
		},
		{
			.Position = {0.5, -0.5f, -0.5f},
			.Color = {1.0f, 1.0f, 0.5f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {-0.5, -0.5f, -0.5f},
			.Color = {1.0f, 1.0f, 0.5f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {-0.5, 0.5f, -0.5f},
			.Color = {1.0f, 1.0f, 0.5f},
			.Uv = {1.0f, 1.0f}
		},
		// Left Face
		{
			.Position = {-0.5, 0.5f, -0.5f},
			.Color = {0.0f, 0.5f, 0.0f},
			.Uv = {0.0f, 1.0f}
		},
		{
			.Position = {-0.5, -0.5f, -0.5f},
			.Color = {0.0f, 0.5f, 0.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {-0.5, -0.5f, 0.5f},
			.Color = {0.0f, 0.5f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {-0.5, 0.5f, 0.5f},
			.Color = {0.0f, 0.5f, 0.0f},
			.Uv = {1.0f, 1.0f}
		},
		// Top Face
		{
			.Position = {-0.5, 0.5f, -0.5f},
			.Color = {0.0f, 1.0f, 0.0f},
			.Uv = {0.0f, 1.0f}
		},
		{
			.Position = {-0.5, 0.5f, 0.5f},
			.Color = {0.0f, 1.0f, 0.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {0.5, 0.5f, 0.5f},
			.Color = {0.0f, 1.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {0.5, 0.5f, -0.5f},
			.Color = {0.0f, 1.0f, 0.0f},
			.Uv = {1.0f, 1.0f}
		},
		// Bottom Face
		{
			.Position = {0.5, -0.5f, 0.5f},
			.Color = {0.0f, 0.5f, 0.0f},
			.Uv = {0.0f, 1.0f}
		},
		{
			.Position = {0.5, -0.5f, -0.5f},
			.Color = {0.0f, 0.5f, 0.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {-0.5, -0.5f, -0.5f},
			.Color = {0.0f, 0.5f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {-0.5, -0.5f, 0.5f},
			.Color = {0.0f, 0.5f, 0.0f},
			.Uv = {1.0f, 1.0f}
		}
	};

	static inline std::vector<Vertex> pyramidVertices{
		// Front Triangle
		{
			.Position = {0.0f, 0.5f, 0.0f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.5f, 1.0f}
		},
		{
			.Position = {-0.5f, -0.5f, 0.5f},
			.Color = {0.0f, 0.0f, 1.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {0.5f, -0.5f, 0.5f},
			.Color = {0.0f, 1.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		// Right Triangle
		{
			.Position = {0.0f, 0.5f, 0.0f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.5f, 1.0f}
		},
		{
			.Position = {0.5f, -0.5f, 0.5f},
			.Color = {0.0f, 0.0f, 1.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {0.5f, -0.5f, -0.5f},
			.Color = {0.0f, 1.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		// Back Traingle
		{
			.Position = {0.0f, 0.5f, 0.0f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.5f, 1.0f}
		},
		{
			.Position = {0.5f, -0.5f, -0.5f},
			.Color = {0.0f, 0.0f, 1.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {-0.5f, -0.5f, -0.5f},
			.Color = {0.0f, 1.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		// Left Triangle
		{
			.Position = {0.0f, 0.5f, 0.0f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.5f, 1.0f}
		},
		{
			.Position = {-0.5f, -0.5f, -0.5f},
			.Color = {0.0f, 0.0f, 1.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {-0.5f, -0.5f, 0.5f},
			.Color = {0.0f, 1.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		// Base
		{
			.Position = {0.5, -0.5f, 0.5f},
			.Color = {0.0f, 0.5f, 0.0f},
			.Uv = {0.0f, 1.0f}
		},
		{
			.Position = {0.5, -0.5f, -0.5f},
			.Color = {0.0f, 0.5f, 0.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {-0.5, -0.5f, -0.5f},
			.Color = {0.0f, 0.5f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {-0.5, -0.5f, 0.5f},
			.Color = {0.0f, 0.5f, 0.0f},
			.Uv = {1.0f, 1.0f}
		}
	};


	static inline std::vector<Vertex> planeVertices{
		{
			.Position = {-1.0f, -1.0f, -1.0f},
			.Color = {0.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 1.0f}
		},
		{
			.Position = {-1.0f, -1.0f, 1.0f},
			.Color = {0.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {1.0f, -1.0f, 1.0f},
			.Color = {0.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {-1.0f, -1.0f, -1.0f},
			.Color = {0.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 1.0f}
		},
		{
			.Position = {1.0f, -1.0f, 1.0f},
			.Color = {0.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {1.0f, -1.0f, -1.0f},
			.Color = {0.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 1.0f}
		}
	};

	static inline std::vector<Vertex> cylinderVertices {
		// Top Circle
		{
			.Position = {0.0f, 0.5f, 0.0f}, // 0-2
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.5f, 1.0f}
		},
		{
			.Position = {0.0f, 0.5f, -0.5f}, 
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {-0.35f, 0.5f, -0.35f}, 
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {0.0f, 0.5f, 0.0f}, // 3-5
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.5f, 1.0f}
		},
		{
			.Position = {-0.35f, 0.5f, -0.35f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {-0.5f, 0.5f, 0.0f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {0.0f, 0.5f, 0.0f}, // 6-8
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.5f, 1.0f}
		},
		{
			.Position = {-0.5f, 0.5f, 0.0f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {-0.35f, 0.5f, 0.35f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {0.0f, 0.5f, 0.0f}, // 9-11
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.5f, 1.0f}
		},
		{
			.Position = {-0.35f, 0.5f, 0.35f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {0.0f, 0.5f, 0.5f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {0.0f, 0.5f, 0.0f}, // 12-14
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.5f, 1.0f}
		},
		{
			.Position = {0.0f, 0.5f, 0.5f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {0.35f, 0.5f, 0.35f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {0.0f, 0.5f, 0.0f}, //15-17
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.5f, 1.0f}
		},
		{
			.Position = {0.35f, 0.5f, 0.35f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {0.5f, 0.5f, 0.0f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {0.0f, 0.5f, 0.0f}, // 18-20
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.5f, 1.0f}
		},
		{
			.Position = {0.5f, 0.5f, 0.0f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {0.35f, 0.5f, -0.35f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {0.0f, 0.5f, 0.0f}, // 21-23
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.5f, 1.0f}
		},
		{
			.Position = {0.35f, 0.5f, -0.35f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {0.0f, 0.5f, -0.5f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		// Cylinder Wall
		{
			.Position = {0.35f, 0.5f, 0.35f}, // 24-26
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 1.0f}
		},
		{
			.Position = {0.35f, -0.5f, 0.35f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {0.5f, -0.5f, 0.0f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {0.35f, 0.5f, 0.35f}, // 27-29
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 1.0f}
		},
		{
			.Position = {0.5f, -0.5f, 0.0f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {0.5f, 0.5f, 0.0f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 1.0f}
		},
		{
			.Position = {0.5f, 0.5f, 0.0f}, // 30-32
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 1.0f}
		},
		{
			.Position = {0.5f, -0.5f, 0.0f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {0.35f, -0.5f, -0.35f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {0.5f, 0.5f, 0.0f}, // 33-35
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 1.0f}
		},
		{
			.Position = {0.35f, -0.5f, -0.35f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {0.35f, 0.5f, -0.35f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 1.0f}
		},
		{
			.Position = {0.35f, 0.5f, -0.35f}, // 36-38
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 1.0f}
		},
		{
			.Position = {0.35f, -0.5f, -0.35f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {0.0f, -0.5f, -0.5f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {0.35f, 0.5f, -0.35f}, // 39-41
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 1.0f}
		},
		{
			.Position = {0.0f, -0.5f, -0.5f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {0.0f, 0.5f, -0.5f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 1.0f}
		},
		{
			.Position = {0.0f, 0.5f, -0.5f}, // 42-44
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 1.0f}
		},
		{
			.Position = {0.0f, -0.5f, -0.5f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {-0.35f, -0.5f, -0.35f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {0.0f, 0.5f, -0.5f}, // 45-47
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 1.0f}
		},
		{
			.Position = {-0.35f, -0.5f, -0.35f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {-0.35f, 0.5f, -0.35f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 1.0f}
		},
		{
			.Position = {-0.35f, 0.5f, -0.35f}, // 48-50
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 1.0f}
		},
		{
			.Position = {-0.35f, -0.5f, -0.35f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {-0.5f, -0.5f, 0.0f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {-0.35f, 0.5f, -0.35f}, // 51-53
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 1.0f}
		},
		{
			.Position = {-0.5f, -0.5f, 0.0f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {-0.5f, 0.5f, 0.0f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 1.0f}
		},
		{
			.Position = {-0.5f, 0.5f, 0.0f}, // 54-56
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 1.0f}
		},
		{
			.Position = {-0.5f, -0.5f, 0.0f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {-0.35f, -0.5f, 0.35f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {-0.5f, 0.5f, 0.0f}, // 57-59
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 1.0f}
		},
		{
			.Position = {-0.35f, -0.5f, 0.35f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {-0.35f, 0.5f, 0.35f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 1.0f}
		},
		{
			.Position = {-0.35f, 0.5f, 0.35f}, // 60-62
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 1.0f}
		},
		{
			.Position = {-0.35f, -0.5f, 0.35f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {0.0f, -0.5f, 0.5f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {-0.35f, 0.5f, 0.35f}, // 63-65
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 1.0f}
		},
		{
			.Position = {0.0f, -0.5f, 0.5f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {0.0f, 0.5f, 0.5f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 1.0f}
		},
		{
			.Position = {0.0f, 0.5f, 0.5f}, // 66-68
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 1.0f}
		},
		{
			.Position = {0.0f, -0.5f, 0.5f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {0.35f, -0.5f, 0.35f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {0.0f, 0.5f, 0.5f}, // 69-71
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 1.0f}
		},
		{
			.Position = {0.35f, -0.5f, 0.35f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {0.35f, 0.5f, 0.35f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 1.0f}
		},
		// Bottom Circle
		{
			.Position = {0.0f, -0.5f, 0.0f}, // 72-74
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.5f, 1.0f}
		},
		{
			.Position = {0.0f, -0.5f, -0.5f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {-0.35f, -0.5f, -0.35f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {0.0f, -0.5f, 0.0f}, // 75-77
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.5f, 1.0f}
		},
		{
			.Position = {-0.35f, -0.5f, -0.35f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {-0.5f, -0.5f, 0.0f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {0.0f, -0.5f, 0.0f}, // 78-80
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.5f, 1.0f}
		},
		{
			.Position = {-0.5f, -0.5f, 0.0f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {-0.35f, -0.5f, 0.35f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {0.0f, -0.5f, 0.0f}, // 81-83
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.5f, 1.0f}
		},
		{
			.Position = {-0.35f, -0.5f, 0.35f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {0.0f, -0.5f, 0.5f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {0.0f, -0.5f, 0.0f}, // 84-86
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.5f, 1.0f}
		},
		{
			.Position = {0.0f, -0.5f, 0.5f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {0.35f, -0.5f, 0.35f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {0.0f, -0.5f, 0.0f}, //87-89
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.5f, 1.0f}
		},
		{
			.Position = {0.35f, -0.5f, 0.35f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {0.5f, -0.5f, 0.0f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {0.0f, -0.5f, 0.0f}, // 90-92
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.5f, 1.0f}
		},
		{
			.Position = {0.5f, -0.5f, 0.0f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {0.35f, -0.5f, -0.35f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},
		{
			.Position = {0.0f, -0.5f, 0.0f}, // 93-95
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.5f, 1.0f}
		},
		{
			.Position = {0.35f, -0.5f, -0.35f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {0.0f, 0.0f}
		},
		{
			.Position = {0.0f, -0.5f, -0.5f},
			.Color = {1.0f, 0.0f, 0.0f},
			.Uv = {1.0f, 0.0f}
		},

	};

	
	static inline std::vector<uint32_t> cubeElements {
		0, 1, 3, 1, 2, 3, // Front Face
		4, 5, 7, 5, 6, 7, // Right Face
		8, 9, 11, 9, 10, 11, // Back Face
		12, 13, 15, 13, 14, 15, // Left Face
		16, 17, 19, 17, 18, 19, // Top Face
		20, 21, 23, 21, 22, 23 // Bottom Face
	};

	static inline std::vector<uint32_t> pyramidElements {
		0, 1, 2,
		3, 4, 5,
		6, 7, 8,
		9, 10, 11, 
		12, 15, 14, 12, 14, 13
	};

	static inline std::vector<uint32_t> planeElements {
		0, 1, 2,
		3, 4, 5
	};

	static inline std::vector<uint32_t> cylinderElements{
		0, 1, 2,
		3, 4, 5,
		6, 7, 8,
		9, 10, 11,
		12, 13, 14,
		15, 16, 17,
		18, 19, 20,
		21, 22, 23,
		24, 25, 26, 27, 28, 29,
		30, 31, 32, 33, 34, 35,
		36, 37, 38, 39, 40, 41, 
		42, 43, 44, 45, 46, 47,
		48, 49, 50, 51, 52, 53,
		54, 55, 56, 57, 58, 59,
		60, 61, 62, 63, 64, 65,
		66, 67, 68, 69, 70, 71,
		72, 73, 74,
		75, 76, 77,
		78, 79, 80,
		81, 82, 83,
		84, 85, 86,
		87, 88, 89,
		90, 91, 92,
		93, 94, 95

	};

};
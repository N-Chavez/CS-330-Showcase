#pragma once

#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <string>
#include <mesh.h>
#include <shader.h>
#include <camera.h>
#include <texture.h>

class Application {
public:
	Application(std::string WindowTitle, int width, int height);

	void Run();

private:
	bool openWindow();
	void setupInputs();
	void setupScene();
	bool update(float deltaTime);
	bool draw();

	void handleInput(float deltaTime);
	void mousePosCallback(double xpos, double ypos);

private:
	std::string _applicationName {};
	int _width {};
	int _height {};
	GLFWwindow* _window{ nullptr };

	float _moveSpeed = { 5.0f };
	Camera _camera;

	std::vector<Mesh> _meshes;
	std::vector<Texture> _textures;
	Shader _shader;

	bool _running{ false };

	bool _firstMouse{ false };
	glm::vec2 _lastMousePosition {};
	glm::vec2 _cameraLookSpeed {};

	float _lastFrameTime { -1.0f };

	float _ambientStrength { 0.1f };
	glm::vec3 _ambientColor { 1.0f, 1.0f, 1.0f };
};
#pragma once

#include <glm/glm.hpp>
#include <shader.h>
#include <mesh.h>
#include <types.h>

class Light {
public:
	Light();

	void Init();

	void Update(float deltaTime);

	void Draw(SceneParameters& sceneParams);

private:
	void createShader();
	void createMesh();

private:
	std::shared_ptr<Shader> _basicUnlitShader {};
	std::shared_ptr<Mesh> _lightMesh {};

	//std::vector<Mesh> _meshes {};

	float totalTime{ 0.0f };
};
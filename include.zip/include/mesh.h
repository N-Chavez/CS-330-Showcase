#pragma once

#include <vector>
#include <shapes.h>
#include <glad/glad.h>
#include <GLFW/glfw3.h>

class Mesh {
public:
	Mesh(std::vector<Vertex>& vertices, std::vector<uint32_t>& elements);
	Mesh(std::vector<Vertex>& vertices, std::vector<uint32_t>& elements, const glm::vec3& color);

	void Draw();

	glm::mat4 Transform{ 1.0f };

private:
	void init(std::vector<Vertex>& vertices, std::vector<uint32_t>& elements);

private:
	uint32_t _elementCount { 0 };
	GLuint _VBO{};
	GLuint _shaderProgram{};
	GLuint _VAO{};
	GLuint _EBO{};
};
#pragma once

#include <glm/glm.hpp>
#include <vector>

constexpr uint8_t MAX_LIGHTS = 2;

struct Vertex {
	glm::vec3 Position{ 0.0f, 0.0f, 0.0f };
	glm::vec3 Color{ 1.0f, 1.0f, 1.0f };
	glm::vec3 Normal{ 0.0f, 0.0f, 0.0f };
	glm::vec2 Uv{ 1.0f, 1.0f };
};

struct DirectionalLight {
	glm::vec3 Direction;

	glm::vec3 AmbientColor;
	glm::vec3 DiffuseColor;
	glm::vec3 SpecularColor;
};

struct SceneParameters {
	glm::mat4 ProjectionMatrix{ 1.0f };
	glm::mat4 ViewMatrix{ 1.0f };

	glm::vec3 CameraPosition {};

	DirectionalLight DirLight {};

	std::vector<glm::vec3> Lights{};
};